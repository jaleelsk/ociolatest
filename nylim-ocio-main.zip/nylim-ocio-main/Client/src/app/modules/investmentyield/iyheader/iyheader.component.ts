import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-iyheader',
  templateUrl: './iyheader.component.html',
  styleUrls: ['./iyheader.component.css']
})
export class IyheaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

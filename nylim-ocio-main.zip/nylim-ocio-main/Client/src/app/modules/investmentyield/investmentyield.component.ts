import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-investmentyield',
  templateUrl: './investmentyield.component.html',
  styleUrls: ['./investmentyield.component.css']
})
export class InvestmentyieldComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

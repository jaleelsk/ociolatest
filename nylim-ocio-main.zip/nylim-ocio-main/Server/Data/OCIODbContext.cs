﻿using Microsoft.EntityFrameworkCore;
using OCIOApi.Models;

namespace OCIOApi.Data
{
    public class OCIODbContext : DbContext
    {
        public DbSet<IndexRate>? IndexRates { get; set; }
        public DbSet<IndexMaster>? Indexes { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySQL("server=ocio-test.cluster-ctha3ic3kgcy.us-east-1.rds.amazonaws.com;database=OCIOTEST;user=ociotest;password=ociotest$123");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<IndexMaster>(entity =>
            {
                entity.ToTable("INDXMAST");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Name).IsRequired();
                entity.Property(e => e.Source).IsRequired();
            });

            modelBuilder.Entity<IndexRate>(entity =>
            {
                entity.ToTable("INDXRATE");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.IndexMasterId).IsRequired();
                entity.Property(e => e.RateDate).IsRequired();
                entity.Property(e => e.Rate).IsRequired();
            });
        }
    }
}

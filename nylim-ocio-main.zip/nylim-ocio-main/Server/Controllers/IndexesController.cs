﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OCIOApi.Data;
using OCIOApi.Models;

namespace OCIOApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class IndexesController : ControllerBase
    {
        private readonly ILogger<IndexRatesController> _logger;
        private readonly OCIODbContext _dbContext;

        public IndexesController(ILogger<IndexRatesController> logger)
        {
            _logger = logger;
            _dbContext = new OCIODbContext();
        }

        [HttpGet]
        public IEnumerable<IndexDto> Get()
        {
            return _dbContext.Indexes
                .Select(i => new IndexDto {  Id = i.Id, Name = i.Name, Source = i.Source })
                .ToArray();
        }
    }
}

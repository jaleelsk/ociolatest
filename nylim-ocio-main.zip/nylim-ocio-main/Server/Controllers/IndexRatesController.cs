﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OCIOApi.Data;
using OCIOApi.Models;

namespace OCIOApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class IndexRatesController : ControllerBase
    {
        private readonly ILogger<IndexRatesController> _logger;
        private readonly OCIODbContext _dbContext;

        public IndexRatesController(ILogger<IndexRatesController> logger)
        {
            _logger = logger;
            _dbContext = new OCIODbContext();
        }

        [HttpGet]
        public IEnumerable<DailyRatesDto> Get()
        {
            var recentDates = _dbContext.IndexRates
                .Select(ir => ir.RateDate)
                .Distinct()
                .OrderByDescending(ir => ir)
                .Take(7)
                .ToArray();
                //.Max(ir => ir.RateDate);
            return _dbContext.IndexRates
                .Where(ir => recentDates.Contains(ir.RateDate))
                .ToList()
                .GroupBy(ir => ir.RateDate)
                .Select(r => new DailyRatesDto
                {
                    RateDate = r.Key,
                    Rates = r.Select(ir => new RateDto { IndexId = ir.IndexMasterId, Rate = ir.Rate }).ToArray()
                })
                .OrderByDescending(ir => ir.RateDate)
                .ToArray();
        }
    }
}

﻿namespace OCIOApi.Models
{
    public class IndexDto
    {
        public int Id { get; set; } 
        public string Name { get; set; }
        public string Source { get; set; }
    }

    public class DailyRatesDto
    {
        public DateTime RateDate { get; set; }
        public RateDto[] Rates { get; set; } = new RateDto[0];
    }

    public class RateDto
    {
        public int IndexId { get; set; }
        public decimal Rate { get; set; }
    }
}

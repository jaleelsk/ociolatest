﻿namespace OCIOApi.Models
{
    public class IndexRate
    {
        public int Id { get; set; }
        public int IndexMasterId { get; set; }
        public DateTime RateDate { get; set; }
        public decimal Rate { get; set; }
    }
}
